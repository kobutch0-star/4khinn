import React, { useState } from 'react';
import { AnimatePresence } from 'motion/react';
import { BirthdayConfig, StepId, ProposalResponse } from './types';
import { DEFAULT_CONFIG } from './data/defaultConfig';
import { FloatingParticles } from './components/FloatingParticles';
import { Step1Opening } from './components/Step1Opening';
import { Step2Memories } from './components/Step2Memories';
import { Step3Necklace } from './components/Step3Necklace';
import { Step4Proposal } from './components/Step4Proposal';
import { Step5FinalMessage } from './components/Step5FinalMessage';

const STORAGE_KEY = 'birthday_surprise_proposal_config';

export default function App() {
  const [config, setConfig] = useState<BirthdayConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.recipientName === 'Sarah') {
          parsed.recipientName = 'Khin';
        }
        if (parsed.senderName === 'Yours Always' || !parsed.senderName) {
          parsed.senderName = 'Mg';
        }
        if (parsed.memoriesTitle === 'A Little Something For You') {
          parsed.memoriesTitle = '';
        }
        if (parsed.photo2Url === 'https://images.unsplash.com/photo-1518199266791-5375a83190b7?auto=format&fit=crop&w=800&q=80') {
          parsed.photo2Url = DEFAULT_CONFIG.photo2Url;
        }
        if (parsed.photo1Caption === 'Every adventure with you is my favorite memory ✨' || parsed.photo1Caption === 'lil moment 🤍' || !parsed.photo1Caption) {
          parsed.photo1Caption = 'lil moment';
        }
        if (parsed.photo2Caption === 'The smile that lights up my whole universe 🌙' || !parsed.photo2Caption) {
          parsed.photo2Caption = 'fav pic';
        }
        if (parsed.memoriesMessage && parsed.memoriesMessage.includes('From the first time')) {
          parsed.memoriesMessage = DEFAULT_CONFIG.memoriesMessage;
        }
        if (parsed.necklaceMessage && (parsed.necklaceMessage.includes('I chose this delicate necklace') || parsed.necklaceMessage.includes('feel cherished'))) {
          parsed.necklaceMessage = DEFAULT_CONFIG.necklaceMessage;
        }
        if (parsed.proposalMessage && (parsed.proposalMessage.includes('Getting to know you and being by your side') || !parsed.proposalMessage.includes('🤍'))) {
          parsed.proposalMessage = DEFAULT_CONFIG.proposalMessage;
        }
        if (parsed.proposalQuestion && (parsed.proposalQuestion.includes('Would you want to be my girlfriend') || parsed.proposalQuestion.includes('❤️'))) {
          parsed.proposalQuestion = DEFAULT_CONFIG.proposalQuestion;
        }
        return { ...DEFAULT_CONFIG, ...parsed };
      }
    } catch {
      // ignore
    }
    return DEFAULT_CONFIG;
  });

  const [currentStep, setCurrentStep] = useState<StepId>(1);
  const [proposalResponse, setProposalResponse] = useState<ProposalResponse>(null);

  const handleSaveConfig = (newConfig: BirthdayConfig) => {
    setConfig(newConfig);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(newConfig));
    } catch {
      // ignore
    }
  };

  const handleRestart = () => {
    setCurrentStep(1);
    setProposalResponse(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNextStep = () => {
    if (currentStep < 5) {
      setCurrentStep((prev) => (prev + 1) as StepId);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevStep = () => {
    if (currentStep > 1) {
      setCurrentStep((prev) => (prev - 1) as StepId);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleProposalAnswer = (response: ProposalResponse) => {
    setProposalResponse(response);
    setCurrentStep(5);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen bg-[#FDF6F0] text-[#4A3F35] flex flex-col ui-font selection:bg-[#F3D7D7] selection:text-[#4A3F35]">
      {/* Background Floating Hearts, Sparkles, and Petals */}
      <FloatingParticles />

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center max-w-5xl w-full mx-auto p-3 sm:p-6">
        <AnimatePresence mode="wait">
          {currentStep === 1 && (
            <Step1Opening
              key="step-1"
              config={config}
              onNext={handleNextStep}
            />
          )}

          {currentStep === 2 && (
            <Step2Memories
              key="step-2"
              config={config}
              onNext={handleNextStep}
              onPrev={handlePrevStep}
              onUpdateConfig={handleSaveConfig}
            />
          )}

          {currentStep === 3 && (
            <Step3Necklace
              key="step-3"
              config={config}
              onNext={handleNextStep}
              onPrev={handlePrevStep}
              onUpdateConfig={handleSaveConfig}
            />
          )}

          {currentStep === 4 && (
            <Step4Proposal
              key="step-4"
              config={config}
              onAnswer={handleProposalAnswer}
              onPrev={handlePrevStep}
            />
          )}

          {currentStep === 5 && (
            <Step5FinalMessage
              key="step-5"
              config={config}
              proposalResponse={proposalResponse}
              onRestart={handleRestart}
            />
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}
