export interface BirthdayConfig {
  recipientName: string;
  senderName: string;
  // Memories
  memoriesTitle: string;
  memoriesMessage: string;
  photo1Url: string;
  photo1Caption: string;
  photo2Url: string;
  photo2Caption: string;
  // Gift content
  necklaceTitle?: string;
  necklaceSubtitle?: string;
  necklaceMessage?: string;
  necklaceImageUrl?: string;
  necklacePendantType?: 'heart' | 'solitaire' | 'butterfly' | 'star' | 'infinity';
  // Proposal content
  proposalIntro: string;
  proposalMessage: string;
  proposalQuestion: string;
  // Final message content
  finalTitle: string;
  finalMessage1: string;
  finalMessage2: string;
  finalClosing: string;
}

export type StepId = 1 | 2 | 3 | 4 | 5;

export type ProposalResponse = 'yes' | 'need_moment' | null;
