import { BirthdayConfig } from '../types';

export const DEFAULT_CONFIG: BirthdayConfig = {
  recipientName: 'Khin',
  senderName: 'Mg',
  
  // Step 2
  memoriesTitle: '',
  memoriesMessage:
    'Happy birthdayပါ ခင် အခုဆိုလူကြီးလေးဖြစ်ပြီပေါ့ ခင့်ဘဝတလျှောက်လုံး ကောင်းခြင်းတွေအကုန်ခင်ပိုင်ဆိုင်ရပါစေလို့ဆုတောင်းပေးပါတယ်နော် မောင့်ဘဝထဲဝင်လာခဲ့ပေးတဲ့အတွက်ကျေးဇူးတင်ပါတယ် ခင် ခင်နဲ့ပြန်တွေ့ရတာကမောင့်အတွက် blessingတခုလိုပါပဲ မောင် ခင့်ဘေးနားမှာ အမြဲရှိနေပါ့မယ်💕',
  photo1Url:
    'https://images.unsplash.com/photo-1522673607200-164d1b6ce486?auto=format&fit=crop&w=800&q=80',
  photo1Caption: 'lil moment',
  photo2Url:
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=800&q=80',
  photo2Caption: 'fav pic',

  // Step 3
  necklaceTitle: 'I got you something special…',
  necklaceSubtitle: 'A small symbol for a person who means the world to me',
  necklaceMessage:
    'You said you like Rose Gold a lot, so i skipped sch to get this for you. I think this was made for you and also u reminds me of ငါ့ရဲ့လမင်း soooo...',
  necklaceImageUrl: '',
  necklacePendantType: 'heart',

  // Step 4
  proposalIntro: "There's one more thing I've been wanting to ask you…",
  proposalMessage:
    "Khin, before I met you again, I honestly forgot what it felt like to be genuinely happy and loved. But somehow, when you came back into my life, everything felt a little brighter. You made me smile again, you made me feel loved again, and you became someone really special to me. I don’t know what the future will look like, but I know I want to experience it with you🤍",
  proposalQuestion:
    'So, Khin... will you be my girlfriend?',

  // Step 5
  finalTitle: 'Happy birthday Khin',
  finalMessage1:
    'Whatever your answer is, I hope you know how deeply special you are to me.',
  finalMessage2:
    'I hope I made your birthday a little brighter, a little sweeter, and unforgettable.',
  finalClosing: 'Happy Birthday ❤️ Forever cheering for your happiness.',
};
