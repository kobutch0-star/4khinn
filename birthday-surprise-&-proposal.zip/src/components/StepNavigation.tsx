import React from 'react';
import { StepId } from '../types';
import { Volume2, VolumeX, Edit3, RotateCcw } from 'lucide-react';
import { romanticAudio } from '../utils/audio';

interface StepNavigationProps {
  currentStep: StepId;
  onSelectStep: (step: StepId) => void;
  isMusicPlaying: boolean;
  onToggleMusic: () => void;
  onOpenPersonalize: () => void;
  onRestart: () => void;
}

export const StepNavigation: React.FC<StepNavigationProps> = ({
  currentStep,
  onSelectStep,
  isMusicPlaying,
  onToggleMusic,
  onOpenPersonalize,
  onRestart,
}) => {
  const steps: { id: StepId; stepTitle: string }[] = [
    { id: 1, stepTitle: 'Happy Birthday' },
    { id: 2, stepTitle: 'Memories & Note' },
    { id: 3, stepTitle: 'The Gift' },
    { id: 4, stepTitle: 'The Question' },
    { id: 5, stepTitle: 'Birthday Message' },
  ];

  const activeStepObj = steps.find((s) => s.id === currentStep) || steps[0];

  return (
    <header className="sticky top-0 z-40 bg-[#FDF6F0]/90 backdrop-blur-md border-b border-[#D9C5B2]/30 transition-all">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between gap-4">
        {/* Left: Natural Tones Progress Dots */}
        <div className="flex items-center gap-2">
          {steps.map((step) => {
            const isActive = currentStep === step.id;
            const isCompleted = currentStep > step.id;
            return (
              <button
                key={step.id}
                onClick={() => {
                  romanticAudio.playSparkleSound();
                  onSelectStep(step.id);
                }}
                title={step.stepTitle}
                className={`transition-all duration-300 rounded-full cursor-pointer ${
                  isActive
                    ? 'w-5 h-2 bg-[#E8A0BF]'
                    : isCompleted
                    ? 'w-2 h-2 rounded-full border border-[#D9C5B2] bg-[#D9C5B2] hover:bg-[#C88A8A]'
                    : 'w-2 h-2 rounded-full border border-[#D9C5B2] hover:bg-[#E5DACE]'
                }`}
              />
            );
          })}
        </div>

        {/* Center: Minimal Step Indicator Text */}
        <div className="ui-font text-[10px] sm:text-[11px] tracking-[0.2em] uppercase text-[#8B7E74] font-medium text-center">
          {activeStepObj.stepTitle}
        </div>

        {/* Right: Sound & Edit Controls */}
        <div className="flex items-center gap-2.5">
          <div className="hidden sm:block w-8 h-[1px] bg-[#D9C5B2]/60 mr-0.5" />

          {/* Music Toggle */}
          <button
            onClick={onToggleMusic}
            className={`p-1.5 sm:p-2 rounded-full border transition-all cursor-pointer ${
              isMusicPlaying
                ? 'bg-[#F3D7D7] border-[#E8A0BF] text-[#6B5E51] shadow-xs'
                : 'bg-white/80 border-[#D9C5B2] text-[#8B7E74] hover:bg-[#F9F0EB]'
            }`}
            title={isMusicPlaying ? 'Sound: On (Click to Mute)' : 'Sound: Off (Click to Play)'}
          >
            {isMusicPlaying ? (
              <Volume2 className="w-3.5 h-3.5 text-[#C88A8A]" />
            ) : (
              <VolumeX className="w-3.5 h-3.5 text-[#8B7E74]" />
            )}
          </button>

          {/* Personalize Button */}
          <button
            onClick={onOpenPersonalize}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/80 hover:bg-[#F9F0EB] text-[#6B5E51] border border-[#D9C5B2] text-xs ui-font font-medium transition-colors cursor-pointer"
            title="Edit her name, photos, or messages"
          >
            <Edit3 className="w-3 h-3 text-[#8B7E74]" />
            <span className="hidden sm:inline">Edit</span>
          </button>

          <button
            onClick={onRestart}
            className="p-1.5 rounded-full text-[#8B7E74] hover:text-[#4A3F35] hover:bg-[#E5DACE]/40 transition-colors cursor-pointer"
            title="Restart from beginning"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </header>
  );
};

