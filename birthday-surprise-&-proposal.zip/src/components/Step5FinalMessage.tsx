import React, { useEffect } from 'react';
import { motion } from 'motion/react';
import { PartyPopper, RotateCcw } from 'lucide-react';
import { BirthdayConfig, ProposalResponse } from '../types';
import { fireHeartConfetti, fireGentleSparkles } from '../utils/confetti';

interface Step5FinalMessageProps {
  config: BirthdayConfig;
  proposalResponse: ProposalResponse;
  onRestart: () => void;
}

export const Step5FinalMessage: React.FC<Step5FinalMessageProps> = ({
  config,
  proposalResponse,
  onRestart,
}) => {
  useEffect(() => {
    // Launch celebratory confetti on mount
    fireHeartConfetti();

    const timer = setTimeout(() => {
      fireGentleSparkles();
    }, 1800);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="w-full flex items-center justify-center py-6 px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-2xl mx-auto text-center"
      >
        {/* Natural Tones Paper Container */}
        <div className="relative paper-texture rounded-[36px] p-6 sm:p-10 border border-[#E5DACE] organic-shadow overflow-hidden">
          {/* Top Washi Tape */}
          <div className="tape-top" />
          <div className="tape-diagonal-left" />
          <div className="tape-diagonal-right" />

          {/* Small Top Corner Start Over Button */}
          <button
            onClick={onRestart}
            className="absolute top-4 right-4 sm:top-5 sm:right-5 p-2 rounded-full bg-white/60 hover:bg-white/90 text-[#8B7E74] hover:text-[#4A3F35] border border-[#E5DACE] shadow-2xs transition-all cursor-pointer z-10"
            title="Start from beginning"
            aria-label="Start over"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#8B7E74]" />
          </button>

          {/* Heading */}
          <h2 className="text-3xl sm:text-5xl scrapbook-font font-semibold text-[#4A3F35] tracking-tight leading-tight mb-4 mt-2 sm:mt-0">
            Happy birthday Khin
          </h2>

          {/* Ending Signoff */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3 }}
            className="my-6"
          >
            <div className="inline-block p-6 sm:p-8 rounded-[32px] bg-[#FAF2EB] border border-[#D9C5B2] organic-shadow max-w-md w-full">
              <p className="scrapbook-font italic text-xl sm:text-2xl text-[#6B5E51] leading-relaxed">
                May all your wishes and sweetest dreams come true for you🤍
              </p>
              <div className="mt-4 pt-3 border-t border-[#D9C5B2]/40 text-right">
                <span className="ui-font text-xs sm:text-sm font-medium tracking-wider text-[#8B7E74]">
                  — {config.senderName}
                </span>
              </div>
            </div>
          </motion.div>

          {/* Action Buttons in Natural Tones */}
          <div className="flex items-center justify-center pt-6 border-t border-[#E5DACE]">
            <button
              onClick={() => {
                fireHeartConfetti();
              }}
              className="inline-flex items-center gap-2 px-8 py-3.5 rounded-full bg-[#E8A0BF] hover:bg-[#D987A9] text-white ui-font text-xs uppercase tracking-wider font-medium organic-shadow transition-colors cursor-pointer"
            >
              <PartyPopper className="w-3.5 h-3.5" />
              <span>Celebrate Again</span>
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
