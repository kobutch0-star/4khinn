import React from 'react';
import { motion } from 'motion/react';

interface MoonStarNecklaceProps {
  className?: string;
}

export const MoonStarNecklace: React.FC<MoonStarNecklaceProps> = ({ className = '' }) => {
  return (
    <div className={`relative flex items-center justify-center select-none ${className}`}>
      {/* Soft studio illumination backing */}
      <div className="absolute inset-0 bg-radial from-white/10 via-transparent to-transparent pointer-events-none" />

      <svg
        viewBox="0 0 400 520"
        className="w-full h-auto max-w-[320px] filter drop-shadow-[0_12px_24px_rgba(0,0,0,0.5)]"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          {/* Gradients for Authentic Rose Gold Metal */}
          <linearGradient id="rgChainLeft" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FAF0EB" />
            <stop offset="25%" stopColor="#E29787" />
            <stop offset="50%" stopColor="#FDE1D9" />
            <stop offset="75%" stopColor="#B86A5A" />
            <stop offset="100%" stopColor="#EAA393" />
          </linearGradient>

          <linearGradient id="rgChainRight" x1="100%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#FDE1D9" />
            <stop offset="30%" stopColor="#C87D6E" />
            <stop offset="60%" stopColor="#FAF0EB" />
            <stop offset="85%" stopColor="#E29787" />
            <stop offset="100%" stopColor="#9C5243" />
          </linearGradient>

          <linearGradient id="rgPendantBody" x1="0%" y1="0%" x2="100%" y2="80%">
            <stop offset="0%" stopColor="#FFF2EE" />
            <stop offset="18%" stopColor="#E5A08F" />
            <stop offset="42%" stopColor="#C87D6E" />
            <stop offset="68%" stopColor="#FAF0EB" />
            <stop offset="85%" stopColor="#E29787" />
            <stop offset="100%" stopColor="#8F483A" />
          </linearGradient>

          <linearGradient id="rgStarBody" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF4F0" />
            <stop offset="35%" stopColor="#E5A08F" />
            <stop offset="70%" stopColor="#C87D6E" />
            <stop offset="100%" stopColor="#8F483A" />
          </linearGradient>

          {/* Diamond Gradients & Glows */}
          <radialGradient id="paveDiamond" cx="35%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="40%" stopColor="#F8FAFC" />
            <stop offset="75%" stopColor="#E2E8F0" />
            <stop offset="100%" stopColor="#94A3B8" />
          </radialGradient>

          <radialGradient id="sparkleFlare" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFFFFF" stopOpacity="1" />
            <stop offset="35%" stopColor="#FFF5F2" stopOpacity="0.8" />
            <stop offset="70%" stopColor="#FFE0D6" stopOpacity="0.3" />
            <stop offset="100%" stopColor="#FFFFFF" stopOpacity="0" />
          </radialGradient>

          <filter id="softGlow" x="-30%" y="-30%" width="160%" height="160%">
            <feGaussianBlur stdDeviation="2" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
        </defs>

        {/* ================= 1. LOWER V-SHAPED CHAIN (DROPS BENEATH MOON) ================= */}
        {/* Shadow layer for depth */}
        <path
          d="M 25 -10 L 200 450 L 375 -10"
          stroke="#42251E"
          strokeWidth="5"
          strokeLinecap="round"
          strokeLinejoin="round"
          opacity="0.4"
        />
        {/* Cable Link Texture Outer V-Chain */}
        <path
          d="M 25 -10 L 200 450 L 375 -10"
          stroke="url(#rgChainLeft)"
          strokeWidth="3.8"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray="5 2.5"
        />
        <path
          d="M 25 -10 L 200 450 L 375 -10"
          stroke="#FFF2EE"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeDasharray="5 2.5"
          opacity="0.7"
        />

        {/* Bottom V tip ring */}
        <circle cx="200" cy="450" r="4" stroke="url(#rgPendantBody)" strokeWidth="2.5" fill="#3D241E" />

        {/* ================= 2. UPPER CHAIN (CONNECTS TO MOON & STAR) ================= */}
        {/* Left Upper Chain to Left Moon Horn */}
        <path
          d="M 45 -10 C 60 85, 115 165, 150 216"
          stroke="url(#rgChainLeft)"
          strokeWidth="4.2"
          strokeDasharray="5 2.5"
        />
        <path
          d="M 45 -10 C 60 85, 115 165, 150 216"
          stroke="#FFF2EE"
          strokeWidth="1.4"
          strokeDasharray="5 2.5"
          opacity="0.8"
        />

        {/* Right Upper Chain Segment 1 (Top to Star) */}
        <path
          d="M 355 -10 C 348 30, 340 55, 332 82"
          stroke="url(#rgChainRight)"
          strokeWidth="4.2"
          strokeDasharray="5 2.5"
        />
        <path
          d="M 355 -10 C 348 30, 340 55, 332 82"
          stroke="#FFF2EE"
          strokeWidth="1.4"
          strokeDasharray="5 2.5"
          opacity="0.8"
        />

        {/* Right Upper Chain Segment 2 (Star to Right Moon Horn) */}
        <path
          d="M 314 116 C 290 155, 268 188, 250 216"
          stroke="url(#rgChainRight)"
          strokeWidth="4.2"
          strokeDasharray="5 2.5"
        />
        <path
          d="M 314 116 C 290 155, 268 188, 250 216"
          stroke="#FFF2EE"
          strokeWidth="1.4"
          strokeDasharray="5 2.5"
          opacity="0.8"
        />

        {/* ================= 3. THE 5-POINT STAR CHARM (UPPER RIGHT CHAIN) ================= */}
        <g transform="translate(325, 96)">
          {/* Star drop shadow */}
          <polygon
            points="0,-28 8,-9 28,-7 13,9 17,29 0,16 -17,29 -13,9 -28,-7 -8,-9"
            fill="#321A15"
            opacity="0.6"
            transform="translate(2, 4)"
          />

          {/* Star 14K Rose Gold Outer Frame */}
          <polygon
            points="0,-28 8,-9 28,-7 13,9 17,29 0,16 -17,29 -13,9 -28,-7 -8,-9"
            fill="url(#rgStarBody)"
            stroke="#8F483A"
            strokeWidth="2.5"
            strokeLinejoin="round"
          />

          {/* Star Top Loop Rings */}
          <circle cx="2" cy="-29" r="4.5" stroke="url(#rgPendantBody)" strokeWidth="2.2" fill="none" />
          <circle cx="-10" cy="22" r="4.5" stroke="url(#rgPendantBody)" strokeWidth="2.2" fill="none" />

          {/* Star Inner Beveled Cavity */}
          <polygon
            points="0,-20 6,-6 20,-5 9,6 12,20 0,11 -12,20 -9,6 -20,-5 -6,-6"
            fill="#4A2821"
            stroke="#C87D6E"
            strokeWidth="1"
          />

          {/* Star Center Diamond Cluster */}
          <circle cx="0" cy="0" r="4.2" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-5" cy="-5" r="2.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.5" />
          <circle cx="5" cy="-5" r="2.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.5" />
          <circle cx="-6" cy="6" r="2.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.5" />
          <circle cx="6" cy="6" r="2.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.5" />

          {/* Prongs & Beading */}
          <circle cx="-2" cy="-2" r="0.8" fill="#FFF2EE" />
          <circle cx="2" cy="-2" r="0.8" fill="#FFF2EE" />
          <circle cx="-2" cy="2" r="0.8" fill="#FFF2EE" />
          <circle cx="2" cy="2" r="0.8" fill="#FFF2EE" />

          {/* Star Brilliant Sparkle Burst */}
          <path
            d="M 0 -11 L 1.5 -2 L 11 0 L 1.5 2 L 0 11 L -1.5 2 L -11 0 L -1.5 -2 Z"
            fill="#FFFFFF"
            filter="url(#softGlow)"
          />
        </g>

        {/* Attachment Jump Rings on Crescent Moon */}
        <circle cx="150" cy="216" r="5.5" stroke="url(#rgPendantBody)" strokeWidth="3" fill="#3D241E" />
        <circle cx="250" cy="216" r="5.5" stroke="url(#rgPendantBody)" strokeWidth="3" fill="#3D241E" />

        {/* ================= 4. CRESCENT MOON PENDANT WITH PAVÉ DIAMONDS ================= */}
        <g transform="translate(200, 260)">
          {/* Deep Ambient Drop Shadow */}
          <path
            d="M 0 -60 C 38 -60, 68 -30, 68 12 C 68 54, 34 86, -10 86 C -48 86, -78 54, -78 12 C -78 -22, -58 -50, -28 -58 C -25 -59, -23 -57, -24 -54 C -48 -25, -45 25, -10 50 C 25 68, 54 35, 54 -2 C 54 -35, 28 -55, 3 -60 Z"
            fill="#2A1410"
            opacity="0.7"
            transform="translate(3, 8) scale(1.04)"
          />

          {/* Rose Gold Outer Crescent Casting */}
          <path
            d="M 0 -60 C 38 -60, 68 -30, 68 12 C 68 54, 34 86, -10 86 C -48 86, -78 54, -78 12 C -78 -22, -58 -50, -28 -58 C -25 -59, -23 -57, -24 -54 C -48 -25, -45 25, -10 50 C 25 68, 54 35, 54 -2 C 54 -35, 28 -55, 3 -60 Z"
            fill="url(#rgPendantBody)"
            stroke="#8F483A"
            strokeWidth="3.2"
            strokeLinejoin="round"
          />

          {/* Inner Channel Cavity for Pavé Stone Setting */}
          <path
            d="M -7 -52 C 26 -52, 56 -24, 56 10 C 56 46, 26 74, -10 74 C -41 74, -66 48, -66 12 C -66 -13, -50 -38, -25 -48 C -40 -22, -38 23, -10 40 C 18 53, 41 25, 41 -2 C 41 -26, 20 -46, -7 -52 Z"
            fill="#3B1E18"
            stroke="#633227"
            strokeWidth="1.5"
          />

          {/* Milgrain Beaded Border Details along inner curve */}
          <path
            d="M -22 -44 C -37 -18, -35 22, -10 38 C 16 50, 38 24, 38 -2"
            stroke="#FFF2EE"
            strokeWidth="1.2"
            strokeDasharray="2 3"
            opacity="0.8"
          />

          {/* ================= PAVÉ DIAMONDS ARRAY (OUTER ROW - 16 GEMS) ================= */}
          <circle cx="-62" cy="12" r="4.0" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-58" cy="27" r="4.3" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-50" cy="41" r="4.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-38" cy="54" r="4.9" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-23" cy="64" r="5.2" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-6" cy="68" r="5.4" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="11" cy="65" r="5.2" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="27" cy="57" r="4.9" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="41" cy="44" r="4.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="51" cy="29" r="4.3" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="54" cy="13" r="4.0" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="49" cy="-2" r="3.7" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="39" cy="-17" r="3.4" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="26" cy="-30" r="3.1" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="10" cy="-41" r="2.7" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />
          <circle cx="-5" cy="-48" r="2.2" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.8" />

          {/* ================= PAVÉ DIAMONDS ARRAY (INNER ROW - 12 GEMS) ================= */}
          <circle cx="-50" cy="22" r="3.0" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="-40" cy="35" r="3.3" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="-28" cy="46" r="3.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="-13" cy="53" r="3.8" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="4" cy="53" r="3.8" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="19" cy="46" r="3.6" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="32" cy="35" r="3.3" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="39" cy="21" r="3.0" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="39" cy="6" r="2.8" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="31" cy="-7" r="2.5" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="20" cy="-18" r="2.2" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />
          <circle cx="6" cy="-29" r="1.9" fill="url(#paveDiamond)" stroke="#E5A08F" strokeWidth="0.6" />

          {/* Prongs & Beading between stones */}
          <g fill="#FFF2EE" opacity="0.9">
            <circle cx="-44" cy="48" r="1" />
            <circle cx="-31" cy="60" r="1" />
            <circle cx="-15" cy="66" r="1" />
            <circle cx="3" cy="67" r="1" />
            <circle cx="20" cy="61" r="1" />
            <circle cx="35" cy="51" r="1" />
            <circle cx="46" cy="37" r="1" />
          </g>

          {/* Multi-Point Diamond Glints & Sparkles */}
          <g transform="translate(-23, 64)">
            <path
              d="M 0 -9 L 1.8 -1.8 L 9 0 L 1.8 1.8 L 0 9 L -1.8 1.8 L -9 0 L -1.8 -1.8 Z"
              fill="#FFFFFF"
              filter="url(#softGlow)"
            />
          </g>
          <g transform="translate(27, 57)">
            <path
              d="M 0 -8 L 1.5 -1.5 L 8 0 L 1.5 1.5 L 0 8 L -1.5 1.5 L -8 0 L -1.5 -1.5 Z"
              fill="#FFFFFF"
              filter="url(#softGlow)"
            />
          </g>
          <g transform="translate(-50, 41)">
            <path
              d="M 0 -7 L 1.2 -1.2 L 7 0 L 1.2 1.2 L 0 7 L -1.2 1.2 L -7 0 L -1.2 -1.2 Z"
              fill="#FFFFFF"
              filter="url(#softGlow)"
            />
          </g>
          <g transform="translate(49, -2)">
            <path
              d="M 0 -6 L 1 -1 L 6 0 L 1 1 L 0 6 L -1 1 L -6 0 L -1 -1 Z"
              fill="#FFFFFF"
              filter="url(#softGlow)"
            />
          </g>
        </g>
      </svg>

      {/* Floating Animated Shimmer Particles */}
      <motion.div
        animate={{ scale: [0.8, 1.4, 0.8], opacity: [0.4, 1, 0.4] }}
        transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
        className="absolute top-20 right-10 w-2.5 h-2.5 bg-white rounded-full blur-[0.5px] pointer-events-none"
      />
      <motion.div
        animate={{ scale: [1, 1.5, 1], opacity: [0.5, 1, 0.5] }}
        transition={{ repeat: Infinity, duration: 2.6, delay: 1.2, ease: 'easeInOut' }}
        className="absolute bottom-28 left-12 w-3 h-3 bg-[#FFE5DD] rounded-full blur-[0.5px] pointer-events-none"
      />
      <motion.div
        animate={{ scale: [0.8, 1.3, 0.8], opacity: [0.3, 0.9, 0.3] }}
        transition={{ repeat: Infinity, duration: 3.4, delay: 0.6, ease: 'easeInOut' }}
        className="absolute bottom-16 right-20 w-2 h-2 bg-white rounded-full blur-[0.5px] pointer-events-none"
      />
    </div>
  );
};
