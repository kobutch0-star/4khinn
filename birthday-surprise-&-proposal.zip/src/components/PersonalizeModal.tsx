import React, { useState } from 'react';
import { BirthdayConfig } from '../types';
import { X, Save, RotateCcw, Image as ImageIcon, Heart, Gift, MessageSquare } from 'lucide-react';
import { DEFAULT_CONFIG } from '../data/defaultConfig';

interface PersonalizeModalProps {
  isOpen: boolean;
  config: BirthdayConfig;
  onSave: (newConfig: BirthdayConfig) => void;
  onClose: () => void;
}

export const PersonalizeModal: React.FC<PersonalizeModalProps> = ({
  isOpen,
  config,
  onSave,
  onClose,
}) => {
  const [formData, setFormData] = useState<BirthdayConfig>(config);
  const [activeTab, setActiveTab] = useState<'basics' | 'memories' | 'necklace' | 'proposal'>('basics');

  if (!isOpen) return null;

  const handleChange = (field: keyof BirthdayConfig, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleFileUpload = (field: 'photo1Url' | 'photo2Url' | 'necklaceImageUrl', file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      if (typeof e.target?.result === 'string') {
        setFormData((prev) => ({ ...prev, [field]: e.target?.result }));
      }
    };
    reader.readAsDataURL(file);
  };

  const handleResetToDefault = () => {
    if (window.confirm('Reset all messages and photos back to default?')) {
      setFormData(DEFAULT_CONFIG);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#4A3F35]/70 backdrop-blur-sm animate-fadeIn">
      <div className="bg-[#FDF6F0] rounded-[32px] max-w-2xl w-full max-h-[90vh] overflow-hidden organic-shadow border border-[#E5DACE] flex flex-col">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-[#E5DACE] flex items-center justify-between bg-white/40">
          <div>
            <h2 className="text-2xl scrapbook-font font-semibold text-[#4A3F35] flex items-center gap-2">
              <span>Personalize Your Surprise</span>
              <span className="text-[#C88A8A] text-lg">✨</span>
            </h2>
            <p className="ui-font text-xs text-[#8B7E74] mt-0.5">
              Customize her name, romantic messages, and special photos for her birthday.
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-[#FAF2EB] text-[#8B7E74] hover:text-[#4A3F35] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Navigation */}
        <div className="flex border-b border-[#E5DACE] bg-[#FAF2EB]/70 px-5 pt-3 gap-2 text-xs ui-font font-medium overflow-x-auto">
          <button
            onClick={() => setActiveTab('basics')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'basics'
                ? 'border-[#E8A0BF] text-[#4A3F35] font-semibold'
                : 'border-transparent text-[#8B7E74] hover:text-[#4A3F35]'
            }`}
          >
            <Heart className="w-3.5 h-3.5" />
            1. Name & Opening
          </button>
          <button
            onClick={() => setActiveTab('memories')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'memories'
                ? 'border-[#E8A0BF] text-[#4A3F35] font-semibold'
                : 'border-transparent text-[#8B7E74] hover:text-[#4A3F35]'
            }`}
          >
            <ImageIcon className="w-3.5 h-3.5" />
            2. Photos & Note
          </button>
          <button
            onClick={() => setActiveTab('necklace')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'necklace'
                ? 'border-[#E8A0BF] text-[#4A3F35] font-semibold'
                : 'border-transparent text-[#8B7E74] hover:text-[#4A3F35]'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            3. The Gift
          </button>
          <button
            onClick={() => setActiveTab('proposal')}
            className={`pb-2.5 px-3 border-b-2 transition-colors flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'proposal'
                ? 'border-[#E8A0BF] text-[#4A3F35] font-semibold'
                : 'border-transparent text-[#8B7E74] hover:text-[#4A3F35]'
            }`}
          >
            <MessageSquare className="w-3.5 h-3.5" />
            4 & 5. Proposal & Closing
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto flex-1 space-y-5">
          {/* TAB 1: BASICS */}
          {activeTab === 'basics' && (
            <div className="space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Her Name (Recipient) *
                </label>
                <input
                  type="text"
                  value={formData.recipientName}
                  onChange={(e) => handleChange('recipientName', e.target.value)}
                  placeholder="e.g. Sarah, Emily, My Love"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-[#D9C5B2] focus:outline-none focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                  required
                />
                <p className="text-[11px] ui-font text-[#8B7E74] mt-1">
                  Appears in “Happy Birthday, [Name] ❤️” and across all love letters.
                </p>
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Your Signature / Nickname
                </label>
                <input
                  type="text"
                  value={formData.senderName}
                  onChange={(e) => handleChange('senderName', e.target.value)}
                  placeholder="e.g. Mg, Alex"
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-[#D9C5B2] focus:outline-none focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>
            </div>
          )}

          {/* TAB 2: MEMORIES & PHOTOS */}
          {activeTab === 'memories' && (
            <div className="space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Step 2 Message Title
                </label>
                <input
                  type="text"
                  value={formData.memoriesTitle}
                  onChange={(e) => handleChange('memoriesTitle', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Heartfelt Birthday Message
                </label>
                <textarea
                  rows={3}
                  value={formData.memoriesMessage}
                  onChange={(e) => handleChange('memoriesMessage', e.target.value)}
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              {/* Photo 1 */}
              <div className="p-4 bg-white/70 rounded-2xl border border-[#D9C5B2]">
                <p className="text-xs ui-font font-semibold text-[#4A3F35] mb-2">Special Photo 1</p>
                <div className="flex items-center gap-3">
                  <img
                    src={formData.photo1Url}
                    alt="Photo 1 preview"
                    className="w-14 h-14 object-cover rounded-lg border border-[#D9C5B2] shadow-xs"
                  />
                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) handleFileUpload('photo1Url', e.target.files[0]);
                      }}
                      className="text-xs file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-xs file:bg-[#FAF2EB] file:text-[#4A3F35] hover:file:bg-[#E5DACE]"
                    />
                    <input
                      type="text"
                      value={formData.photo1Caption}
                      onChange={(e) => handleChange('photo1Caption', e.target.value)}
                      placeholder="Polaroid caption..."
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-[#D9C5B2] bg-white"
                    />
                  </div>
                </div>
              </div>

              {/* Photo 2 */}
              <div className="p-4 bg-white/70 rounded-2xl border border-[#D9C5B2]">
                <p className="text-xs ui-font font-semibold text-[#4A3F35] mb-2">Special Photo 2</p>
                <div className="flex items-center gap-3">
                  <img
                    src={formData.photo2Url}
                    alt="Photo 2 preview"
                    className="w-14 h-14 object-cover rounded-lg border border-[#D9C5B2] shadow-xs"
                  />
                  <div className="flex-1 space-y-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) handleFileUpload('photo2Url', e.target.files[0]);
                      }}
                      className="text-xs file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-xs file:bg-[#FAF2EB] file:text-[#4A3F35] hover:file:bg-[#E5DACE]"
                    />
                    <input
                      type="text"
                      value={formData.photo2Caption}
                      onChange={(e) => handleChange('photo2Caption', e.target.value)}
                      placeholder="Polaroid caption..."
                      className="w-full px-3 py-1.5 text-xs rounded-lg border border-[#D9C5B2] bg-white"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: THE NECKLACE */}
          {activeTab === 'necklace' && (
            <div className="space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Gift Box Headline
                </label>
                <input
                  type="text"
                  value={formData.necklaceTitle || ''}
                  onChange={(e) => handleChange('necklaceTitle', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Why you chose this gift for her
                </label>
                <textarea
                  rows={3}
                  value={formData.necklaceMessage || ''}
                  onChange={(e) => handleChange('necklaceMessage', e.target.value)}
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              {/* Necklace Photo */}
              <div className="p-4 bg-white/70 rounded-2xl border border-[#D9C5B2]">
                <p className="text-xs ui-font font-semibold text-[#4A3F35] mb-2">Necklace Image (Optional)</p>
                <div className="flex items-center gap-3">
                  {formData.necklaceImageUrl && (
                    <img
                      src={formData.necklaceImageUrl}
                      alt="Necklace preview"
                      className="w-14 h-14 object-cover rounded-lg border border-[#D9C5B2] shadow-xs"
                    />
                  )}
                  <div className="flex-1">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => {
                        if (e.target.files?.[0]) handleFileUpload('necklaceImageUrl', e.target.files[0]);
                      }}
                      className="text-xs file:mr-2 file:py-1 file:px-2.5 file:rounded-md file:border-0 file:text-xs file:bg-[#FAF2EB] file:text-[#4A3F35] hover:file:bg-[#E5DACE]"
                    />
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: PROPOSAL & CLOSING */}
          {activeTab === 'proposal' && (
            <div className="space-y-4 animate-fadeIn">
              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Emotional Buildup Intro
                </label>
                <input
                  type="text"
                  value={formData.proposalIntro}
                  onChange={(e) => handleChange('proposalIntro', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Message about making things official
                </label>
                <textarea
                  rows={3}
                  value={formData.proposalMessage}
                  onChange={(e) => handleChange('proposalMessage', e.target.value)}
                  className="w-full px-4 py-2.5 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white text-[#4A3F35]"
                />
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  The Big Question
                </label>
                <input
                  type="text"
                  value={formData.proposalQuestion}
                  onChange={(e) => handleChange('proposalQuestion', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] focus:ring-2 focus:ring-[#E8A0BF] bg-white scrapbook-font text-lg text-[#4A3F35]"
                />
              </div>

              <hr className="border-[#E5DACE]" />

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Final Note Line 1
                </label>
                <input
                  type="text"
                  value={formData.finalMessage1}
                  onChange={(e) => handleChange('finalMessage1', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] bg-white text-[#4A3F35]"
                />
              </div>

              <div>
                <label className="block text-xs ui-font font-semibold text-[#4A3F35] mb-1">
                  Final Note Line 2
                </label>
                <input
                  type="text"
                  value={formData.finalMessage2}
                  onChange={(e) => handleChange('finalMessage2', e.target.value)}
                  className="w-full px-4 py-2 text-sm rounded-xl border border-[#D9C5B2] bg-white text-[#4A3F35]"
                />
              </div>
            </div>
          )}

          {/* Footer Actions */}
          <div className="pt-4 border-t border-[#E5DACE] flex items-center justify-between gap-3">
            <button
              type="button"
              onClick={handleResetToDefault}
              className="flex items-center gap-1 text-xs ui-font text-[#8B7E74] hover:text-[#4A3F35] transition-colors"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset to default
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs ui-font font-medium rounded-full border border-[#D9C5B2] text-[#8B7E74] hover:bg-[#FAF2EB] transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-5 py-2 text-xs ui-font font-medium rounded-full bg-[#E8A0BF] hover:bg-[#D987A9] text-white organic-shadow transition-colors"
              >
                <Save className="w-3.5 h-3.5" />
                Save Changes
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
