import React, { useMemo } from 'react';

interface Particle {
  id: number;
  type: 'heart' | 'sparkle' | 'star' | 'circle';
  left: number;
  size: number;
  duration: number;
  delay: number;
  color: string;
}

export const FloatingParticles: React.FC = () => {
  const particles = useMemo<Particle[]>(() => {
    const types: Particle['type'][] = ['heart', 'sparkle', 'star', 'circle'];
    const colors = [
      'rgba(232, 160, 191, 0.45)', // dusty rose #E8A0BF
      'rgba(243, 215, 215, 0.55)', // soft blush #F3D7D7
      'rgba(200, 138, 138, 0.4)', // vintage rose #C88A8A
      'rgba(249, 217, 73, 0.35)', // subtle golden sparkle #F9D949
      'rgba(217, 197, 178, 0.45)', // warm beige #D9C5B2
    ];

    return Array.from({ length: 28 }).map((_, i) => ({
      id: i,
      type: types[i % types.length],
      left: Math.random() * 96 + 2, // 2% to 98%
      size: Math.random() * 14 + 10,
      duration: Math.random() * 8 + 9, // 9s to 17s
      delay: Math.random() * 6,
      color: colors[i % colors.length],
    }));
  }, []);

  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-0" aria-hidden="true">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute"
          style={{
            left: `${p.left}%`,
            bottom: '-40px',
            animation: `floatUp ${p.duration}s linear infinite`,
            animationDelay: `${p.delay}s`,
          }}
        >
          {p.type === 'heart' && (
            <svg
              width={p.size}
              height={p.size}
              viewBox="0 0 24 24"
              fill={p.color}
              className="drop-shadow-sm opacity-80"
            >
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
            </svg>
          )}

          {p.type === 'sparkle' && (
            <svg
              width={p.size}
              height={p.size}
              viewBox="0 0 24 24"
              fill={p.color}
              className="animate-spin"
              style={{ animationDuration: '8s' }}
            >
              <path d="M12 0L14.59 9.41L24 12L14.59 14.59L12 24L9.41 14.59L0 12L9.41 9.41L12 0Z" />
            </svg>
          )}

          {p.type === 'star' && (
            <svg
              width={p.size * 0.8}
              height={p.size * 0.8}
              viewBox="0 0 24 24"
              fill={p.color}
              className="opacity-70"
            >
              <polygon points="12,2 15.09,8.26 22,9.27 17,14.14 18.18,21.02 12,17.77 5.82,21.02 7,14.14 2,9.27 8.91,8.26" />
            </svg>
          )}

          {p.type === 'circle' && (
            <div
              style={{
                width: `${p.size * 0.6}px`,
                height: `${p.size * 0.6}px`,
                backgroundColor: p.color,
                borderRadius: '50%',
                filter: 'blur(1px)',
              }}
            />
          )}
        </div>
      ))}
      <style>{`
        @keyframes floatUp {
          0% {
            transform: translateY(0) rotate(0deg) scale(0.8);
            opacity: 0;
          }
          15% {
            opacity: 0.85;
          }
          85% {
            opacity: 0.85;
          }
          100% {
            transform: translateY(-110vh) rotate(360deg) scale(1.15);
            opacity: 0;
          }
        }
      `}</style>
    </div>
  );
};
