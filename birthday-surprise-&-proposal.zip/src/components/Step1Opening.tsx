import React from 'react';
import { motion } from 'motion/react';
import { Sparkles, Heart, Gift } from 'lucide-react';
import { BirthdayConfig } from '../types';
import { romanticAudio } from '../utils/audio';
import { fireGentleSparkles } from '../utils/confetti';

interface Step1OpeningProps {
  config: BirthdayConfig;
  onNext: () => void;
}

export const Step1Opening: React.FC<Step1OpeningProps> = ({ config, onNext }) => {
  const handleOpenSurprise = () => {
    romanticAudio.playCelebrationSound();
    romanticAudio.startAmbientMusic();
    fireGentleSparkles();
    onNext();
  };

  return (
    <div className="w-full flex items-center justify-center py-6 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20, scale: 0.97 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={{ opacity: 0, y: -20, scale: 0.97 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-xl mx-auto"
      >
        {/* Natural Tones Paper Container */}
        <div className="relative paper-texture rounded-[32px] p-8 sm:p-12 border border-[#E5DACE] organic-shadow overflow-hidden text-center">
          
          {/* Top Washi Tape */}
          <div className="tape-top" />
          <div className="tape-diagonal-left" />
          <div className="tape-diagonal-right" />

          {/* Main Greeting Typography */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.6 }}
            className="my-8 sm:my-10"
          >
            <h1 className="text-4xl sm:text-5xl md:text-6xl scrapbook-font text-[#4A3F35] font-semibold tracking-tight leading-tight">
              Happy Birthday, <br />
              <span className="relative inline-block text-[#C88A8A] italic">
                <span className="relative z-10">{config.recipientName}</span>
              </span>
            </h1>
          </motion.div>

          {/* Action Button: Natural Tones Theme */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.5 }}
            className="flex flex-col items-center gap-3"
          >
            <button
              id="open-birthday-surprise-btn"
              onClick={handleOpenSurprise}
              className="group relative inline-flex items-center justify-center gap-3 px-10 py-4 text-base font-medium text-white bg-[#E8A0BF] hover:bg-[#D987A9] rounded-full organic-shadow ui-font tracking-wide transition-all duration-300 cursor-pointer"
            >
              <Gift className="w-4 h-4 group-hover:rotate-12 transition-transform duration-300" />
              <span>Made smth for you</span>
              <Sparkles className="w-4 h-4 text-[#FDF6F0] animate-spin" style={{ animationDuration: '6s' }} />
            </button>
          </motion.div>
        </div>
      </motion.div>
    </div>
  );
};
