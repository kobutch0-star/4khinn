import React, { useState, useRef } from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles, ArrowRight, ArrowLeft, ZoomIn, Camera, Upload } from 'lucide-react';
import { BirthdayConfig } from '../types';
import { romanticAudio } from '../utils/audio';

interface Step2MemoriesProps {
  config: BirthdayConfig;
  onNext: () => void;
  onPrev: () => void;
  onUpdateConfig?: (newConfig: BirthdayConfig) => void;
}

export const Step2Memories: React.FC<Step2MemoriesProps> = ({ config, onNext, onPrev, onUpdateConfig }) => {
  const [selectedPhoto, setSelectedPhoto] = useState<string | null>(null);
  const photo1InputRef = useRef<HTMLInputElement>(null);
  const photo2InputRef = useRef<HTMLInputElement>(null);

  const handleContinue = () => {
    romanticAudio.playSparkleSound();
    onNext();
  };

  const handlePhotoUpload = (key: 'photo1Url' | 'photo2Url', file: File) => {
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string' && onUpdateConfig) {
        onUpdateConfig({
          ...config,
          [key]: reader.result,
        });
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="w-full flex items-center justify-center py-6 px-4">
      <motion.div
        initial={{ opacity: 0, x: 30 }}
        animate={{ opacity: 1, x: 0 }}
        exit={{ opacity: 0, x: -30 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-2xl mx-auto"
      >
        {/* Scrapbook Journal Page */}
        <div className="relative paper-texture rounded-[32px] p-6 sm:p-10 border border-[#E5DACE] organic-shadow overflow-hidden">
          {/* Washi Tapes */}
          <div className="tape-top" />
          <div className="tape-diagonal-left" />

          {/* Section Header if title provided */}
          {config.memoriesTitle ? (
            <div className="text-center mb-5 pt-2">
              <h2 className="text-2xl sm:text-4xl scrapbook-font font-semibold text-[#4A3F35] tracking-tight">
                {config.memoriesTitle}
              </h2>
            </div>
          ) : null}

          {/* Heartfelt Note Box */}
          <div className="relative bg-white/70 p-5 sm:p-7 rounded-[24px] border border-white/80 organic-shadow mb-8">
            <p className="scrapbook-font text-base sm:text-lg text-[#5A4D40] leading-relaxed sm:leading-loose pt-1 break-words">
              {config.memoriesMessage}
            </p>

            <div className="mt-5 flex items-center justify-end pt-3 border-t border-[#D9C5B2]/40">
              <span className="ui-font text-xs sm:text-sm font-medium tracking-wider text-[#8B7E74]">
                — {config.senderName}
              </span>
            </div>
          </div>

          {/* Natural Tones Special Photo Frames */}
          <div className="mb-8">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 max-w-lg mx-auto">
              {/* Photo 1 Frame */}
              <motion.div
                whileHover={{ scale: 1.02, rotate: 0 }}
                className="photo-frame p-4 bg-white rounded-sm organic-shadow relative z-10 group transition-transform duration-300"
              >
                <input
                  type="file"
                  ref={photo1InputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handlePhotoUpload('photo1Url', e.target.files[0]);
                  }}
                />
                <div 
                  className="w-full aspect-[4/5] bg-[#E5DACE] flex items-center justify-center overflow-hidden rounded-xs relative cursor-pointer"
                  onClick={() => setSelectedPhoto(config.photo1Url)}
                >
                  <img
                    src={config.photo1Url}
                    alt="Special memory 1"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-[#4A3F35]/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedPhoto(config.photo1Url);
                      }}
                      className="p-2 rounded-full bg-white/90 text-[#4A3F35] shadow-md hover:bg-white transition-colors"
                      title="Zoom photo"
                    >
                      <ZoomIn className="w-4 h-4 text-[#C88A8A]" />
                    </button>
                    {onUpdateConfig && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          photo1InputRef.current?.click();
                        }}
                        className="p-2 rounded-full bg-white/90 text-[#4A3F35] shadow-md hover:bg-white transition-colors"
                        title="Upload new photo"
                      >
                        <Camera className="w-4 h-4 text-[#C88A8A]" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-4 scrapbook-font italic text-[#6B5E51] text-base sm:text-lg text-center px-1">
                  “{config.photo1Caption}”
                </div>
              </motion.div>

              {/* Photo 2 Frame */}
              <motion.div
                whileHover={{ scale: 1.02, rotate: 0 }}
                className="photo-frame p-4 bg-white rounded-sm organic-shadow relative z-10 group transition-transform duration-300"
                style={{ transform: 'rotate(2deg)' }}
              >
                <input
                  type="file"
                  ref={photo2InputRef}
                  accept="image/*"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) handlePhotoUpload('photo2Url', e.target.files[0]);
                  }}
                />
                <div 
                  className="w-full aspect-[4/5] bg-[#E5DACE] flex items-center justify-center overflow-hidden rounded-xs relative cursor-pointer"
                  onClick={() => setSelectedPhoto(config.photo2Url)}
                >
                  <img
                    src={config.photo2Url}
                    alt="Special memory 2"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-[#4A3F35]/25 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setSelectedPhoto(config.photo2Url);
                      }}
                      className="p-2 rounded-full bg-white/90 text-[#4A3F35] shadow-md hover:bg-white transition-colors"
                      title="Zoom photo"
                    >
                      <ZoomIn className="w-4 h-4 text-[#C88A8A]" />
                    </button>
                    {onUpdateConfig && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          photo2InputRef.current?.click();
                        }}
                        className="p-2 rounded-full bg-white/90 text-[#4A3F35] shadow-md hover:bg-white transition-colors"
                        title="Upload / change photo"
                      >
                        <Camera className="w-4 h-4 text-[#C88A8A]" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="mt-4 scrapbook-font italic text-[#6B5E51] text-base sm:text-lg text-center px-1">
                  “{config.photo2Caption}”
                </div>
              </motion.div>
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-5 border-t border-[#E5DACE]">
            <button
              onClick={onPrev}
              className="px-6 py-2.5 border border-[#D9C5B2] text-[#8B7E74] hover:bg-[#F9F0EB] rounded-full ui-font text-xs uppercase tracking-wider font-medium transition-colors flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back
            </button>

            <button
              onClick={handleContinue}
              className="px-8 py-3 bg-[#E8A0BF] hover:bg-[#D987A9] text-white rounded-full ui-font text-xs uppercase tracking-wider font-medium organic-shadow transition-all flex items-center gap-2"
            >
              <span>A lil gift</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </motion.div>

      {/* Lightbox / Zoom Modal */}
      {selectedPhoto && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#4A3F35]/80 backdrop-blur-sm animate-fadeIn"
          onClick={() => setSelectedPhoto(null)}
        >
          <div className="relative max-w-xl max-h-[85vh] bg-white p-4 rounded-sm shadow-2xl">
            <img
              src={selectedPhoto}
              alt="Enlarged memory"
              className="max-h-[70vh] w-auto object-contain rounded-xs"
            />
            <p className="text-center scrapbook-font italic text-lg text-[#6B5E51] mt-3">
              Click anywhere to close ✨
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
