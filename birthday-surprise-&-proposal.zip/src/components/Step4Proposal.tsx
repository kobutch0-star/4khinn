import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles, ArrowLeft } from 'lucide-react';
import { BirthdayConfig, ProposalResponse } from '../types';
import { romanticAudio } from '../utils/audio';
import { fireHeartConfetti } from '../utils/confetti';

interface Step4ProposalProps {
  config: BirthdayConfig;
  onAnswer: (response: ProposalResponse) => void;
  onPrev: () => void;
}

export const Step4Proposal: React.FC<Step4ProposalProps> = ({ config, onAnswer, onPrev }) => {
  const [selectedAnswer, setSelectedAnswer] = useState<ProposalResponse>(null);
  const [isSwapped, setIsSwapped] = useState(false);
  const [dodgeCount, setDodgeCount] = useState(0);

  const handleYes = () => {
    setSelectedAnswer('yes');
    onAnswer('yes');
  };

  const handleDodge = (e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    romanticAudio.playSparkleSound();
    setIsSwapped((prev) => !prev);
    setDodgeCount((prev) => prev + 1);
  };

  const yesButton = (
    <motion.button
      key="yes-btn"
      layout
      id="proposal-yes-btn"
      onClick={handleYes}
      disabled={selectedAnswer === 'yes'}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className="w-full sm:w-auto px-10 py-4.5 bg-[#E8A0BF] hover:bg-[#D987A9] text-white rounded-full ui-font font-medium tracking-wide organic-shadow transition-all duration-200 cursor-pointer flex items-center justify-center text-base shadow-sm"
    >
      <span>YES</span>
    </motion.button>
  );

  const noButton = (
    <motion.button
      key="no-btn"
      layout
      id="proposal-no-btn"
      onClick={handleDodge}
      onMouseEnter={handleDodge}
      whileHover={{ scale: 0.95 }}
      whileTap={{ scale: 0.9 }}
      className="w-full sm:w-auto px-10 py-4.5 border border-[#D9C5B2] text-[#8B7E74] bg-[#FAF2EB]/60 hover:bg-[#F9F0EB] rounded-full ui-font font-medium tracking-wide transition-all cursor-pointer flex items-center justify-center text-base select-none"
    >
      <span>NO</span>
    </motion.button>
  );

  return (
    <div className="w-full flex items-center justify-center py-4 px-2 sm:px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.96 }}
        transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-2xl mx-auto"
      >
        {/* Natural Tones Paper Container */}
        <div className="relative paper-texture rounded-[36px] p-6 sm:p-10 border border-[#E5DACE] organic-shadow overflow-hidden text-center">
          {/* Decorative Washi Tapes */}
          <div className="tape-top" />
          <div className="tape-diagonal-left" />
          <div className="tape-diagonal-right" />

          {/* Main Proposal Content */}
          <div className="w-full flex flex-col items-center">
            <h1 className="scrapbook-font text-3xl sm:text-5xl text-[#4A3F35] leading-tight mb-6 font-normal">
              There's smth i want to sayyyy
            </h1>

            {/* Proposal Box in Natural Tones */}
            <div className="w-full p-6 sm:p-8 bg-white/70 border border-white/80 rounded-[28px] organic-shadow mb-8 text-left">
              <p className="scrapbook-font text-lg sm:text-xl text-[#5A4D40] leading-relaxed whitespace-pre-line">
                {config.proposalMessage}
                <br />
                <br />
                <span className="font-semibold text-[#4A3F35] text-lg sm:text-xl block mt-1">
                  {config.proposalQuestion}
                </span>
              </p>
            </div>

            {/* Action Buttons styled with playful swapping */}
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
              {isSwapped ? (
                <>
                  {noButton}
                  {yesButton}
                </>
              ) : (
                <>
                  {yesButton}
                  {noButton}
                </>
              )}
            </div>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-start pt-6 border-t border-[#E5DACE] mt-8">
            <button
              onClick={onPrev}
              className="px-6 py-2.5 border border-[#D9C5B2] text-[#8B7E74] hover:bg-[#F9F0EB] rounded-full ui-font text-xs uppercase tracking-wider font-medium transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
