import React, { useState, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Gift, Sparkles, Heart, ArrowRight, ArrowLeft, Camera, Image as ImageIcon } from 'lucide-react';
import { BirthdayConfig } from '../types';
import { romanticAudio } from '../utils/audio';
import { fireGentleSparkles } from '../utils/confetti';
import { MoonStarNecklace } from './MoonStarNecklace';

interface Step3NecklaceProps {
  config: BirthdayConfig;
  onNext: () => void;
  onPrev: () => void;
  onUpdateConfig?: (updates: Partial<BirthdayConfig>) => void;
}

export const Step3Necklace: React.FC<Step3NecklaceProps> = ({ config, onNext, onPrev, onUpdateConfig }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [customImage, setCustomImage] = useState<string | null>(config.necklaceImageUrl || null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const handleOpenBox = () => {
    if (!isOpen) {
      setIsOpen(true);
      romanticAudio.playGiftUnwrapSound();
      fireGentleSparkles();
    }
  };

  const handleNextStep = () => {
    romanticAudio.playCelebrationSound();
    onNext();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        const url = event.target?.result as string;
        setCustomImage(url);
        if (onUpdateConfig) {
          onUpdateConfig({ necklaceImageUrl: url });
        }
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="w-full flex items-center justify-center py-6 px-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className="relative w-full max-w-2xl mx-auto"
      >
        {/* Natural Tones Paper Container */}
        <div className="relative paper-texture rounded-[32px] p-6 sm:p-10 border border-[#E5DACE] organic-shadow overflow-hidden">
          {/* Top Tape */}
          <div className="tape-top" />

          {/* Interactive Gift Box / Necklace Display Area */}
          <div className="min-h-[300px] sm:min-h-[340px] flex flex-col items-center justify-center my-4">
            <AnimatePresence mode="wait">
              {!isOpen ? (
                /* Unopened Gift Box State */
                <motion.div
                  key="closed-box"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.8, rotate: 6 }}
                  className="flex flex-col items-center text-center cursor-pointer group"
                  onClick={handleOpenBox}
                >
                  {/* Glowing Aura */}
                  <div className="relative mb-6">
                    <div className="absolute inset-0 bg-[#F3D7D7]/40 rounded-full blur-2xl group-hover:bg-[#E8A0BF]/40 transition-all duration-500 scale-125" />
                    
                    {/* Animated Gift Box Container in Dusty Rose */}
                    <motion.div
                      whileHover={{ scale: 1.05, rotate: [0, -2, 2, 0] }}
                      whileTap={{ scale: 0.95 }}
                      transition={{ duration: 0.4 }}
                      className="relative w-40 h-40 sm:w-48 sm:h-48 rounded-[28px] bg-gradient-to-br from-[#F3D7D7] via-[#E8A0BF] to-[#D987A9] p-1 organic-shadow flex items-center justify-center border-4 border-white"
                    >
                      {/* Ribbon Cross in Natural Taupe/Cream */}
                      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-7 bg-[#FAF2EB] shadow-xs flex items-center justify-center" />
                      <div className="absolute inset-y-0 left-1/2 -translate-x-1/2 w-7 bg-[#FAF2EB] shadow-xs" />

                      {/* Bow On Top */}
                      <div className="absolute -top-5 left-1/2 -translate-x-1/2 z-20 flex items-center justify-center">
                        <div className="w-12 h-8 rounded-full bg-[#FAF2EB] border-2 border-white shadow-xs transform -rotate-12 -mr-3" />
                        <div className="w-12 h-8 rounded-full bg-[#FAF2EB] border-2 border-white shadow-xs transform rotate-12 -ml-3" />
                        <div className="absolute w-5 h-5 rounded-full bg-[#E5DACE] border border-white shadow-inner" />
                      </div>

                      {/* Floating sparkle icons */}
                      <Sparkles className="absolute top-3 right-3 w-5 h-5 text-white animate-spin" style={{ animationDuration: '6s' }} />
                      <Heart className="absolute bottom-3 left-3 w-4 h-4 text-white fill-white/80 animate-pulse" />
                    </motion.div>
                  </div>

                  {/* Click instruction */}
                  <motion.div
                    animate={{ y: [0, -3, 0] }}
                    transition={{ repeat: Infinity, duration: 1.8 }}
                  >
                    <button className="px-8 py-3.5 rounded-full bg-[#E8A0BF] hover:bg-[#D987A9] text-white ui-font text-xs uppercase tracking-wider font-medium organic-shadow transition-colors flex items-center gap-2 mx-auto">
                      <Gift className="w-4 h-4" />
                      <span>OPEN ITTT!!!!!</span>
                    </button>
                  </motion.div>
                </motion.div>
              ) : (
                /* Opened Necklace Reveal State */
                <motion.div
                  key="opened-box"
                  initial={{ opacity: 0, scale: 0.8, y: 20 }}
                  animate={{ opacity: 1, scale: 1, y: 0 }}
                  transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
                  className="w-full space-y-6"
                >
                  {/* Natural Tones Velvet Display Box */}
                  <div className="relative max-w-md mx-auto bg-[#4A3F35] rounded-[32px] p-6 border-4 border-[#D9C5B2] organic-shadow overflow-hidden text-center">
                    {/* Interior gradient */}
                    <div className="absolute inset-0 bg-radial from-[#6B5E51]/40 via-[#4A3F35] to-[#362E27] opacity-95" />
                    <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-32 bg-[#F3D7D7]/15 rounded-full blur-xl" />

                    {/* Quick upload trigger */}
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileChange}
                      accept="image/*"
                      className="hidden"
                    />

                    {/* Necklace Pendant / Gift Display */}
                    <div className="relative z-10 py-2 flex flex-col items-center">
                      {customImage ? (
                        <div className="relative my-2 w-56 h-56 sm:w-64 sm:h-64 rounded-2xl overflow-hidden border-2 border-[#D9C5B2] shadow-2xl bg-white flex items-center justify-center p-2 group">
                          <img
                            src={customImage}
                            alt="The Rose Gold Moon & Star Necklace"
                            className="w-full h-full object-contain transition-transform duration-500 group-hover:scale-105"
                          />
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            className="absolute bottom-2 right-2 p-2 bg-[#4A3F35]/80 hover:bg-[#4A3F35] text-white rounded-full backdrop-blur-xs transition-colors"
                            title="Change photo"
                          >
                            <Camera className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ) : (
                        <div className="relative w-full max-w-[290px] my-1 mx-auto group">
                          <MoonStarNecklace />
                          <button
                            onClick={() => fileInputRef.current?.click()}
                            className="absolute top-2 right-2 p-1.5 bg-black/40 hover:bg-black/70 text-white/80 hover:text-white rounded-full transition-all text-[10px] flex items-center gap-1 opacity-60 hover:opacity-100"
                            title="Upload custom image"
                          >
                            <ImageIcon className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Why I chose it note */}
                  <motion.div
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: 0.3 }}
                    className="bg-white/70 p-4 sm:p-6 rounded-[22px] border border-white/80 organic-shadow text-left relative"
                  >
                    <p className="scrapbook-font text-sm sm:text-base text-[#5A4D40] leading-relaxed break-words font-normal">
                      {config.necklaceMessage}
                    </p>
                  </motion.div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between pt-5 border-t border-[#E5DACE] mt-6">
            <button
              onClick={onPrev}
              className="px-6 py-2.5 border border-[#D9C5B2] text-[#8B7E74] hover:bg-[#F9F0EB] rounded-full ui-font text-xs uppercase tracking-wider font-medium transition-colors flex items-center gap-1.5"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Back
            </button>

            {isOpen && (
              <button
                onClick={handleNextStep}
                className="px-8 py-3 bg-[#E8A0BF] hover:bg-[#D987A9] text-white rounded-full ui-font text-xs uppercase tracking-wider font-medium organic-shadow transition-all flex items-center gap-2"
              >
                <span>There's one more thing…</span>
                <Heart className="w-3.5 h-3.5 fill-white" />
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
};

