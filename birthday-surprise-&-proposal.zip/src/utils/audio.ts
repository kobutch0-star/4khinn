/**
 * Audio engine - completely disabled / muted per user request.
 */

class RomanticAudioEngine {
  startAmbientMusic() {}
  stopAmbientMusic() {}
  toggleMusic(): boolean {
    return false;
  }
  isMusicPlaying() {
    return false;
  }
  playCelebrationSound() {}
  playSparkleSound() {}
  playGiftUnwrapSound() {}
  playChime() {}
}

export const romanticAudio = new RomanticAudioEngine();

