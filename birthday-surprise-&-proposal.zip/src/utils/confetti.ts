import confetti from 'canvas-confetti';

export function fireHeartConfetti() {
  // Fire colorful hearts and sparkles
  const count = 180;
  const defaults = {
    origin: { y: 0.7 },
    zIndex: 1000,
  };

  function fire(particleRatio: number, opts: confetti.Options) {
    confetti({
      ...defaults,
      ...opts,
      particleCount: Math.floor(count * particleRatio),
    });
  }

  fire(0.25, {
    spread: 26,
    startVelocity: 55,
    colors: ['#ff4d6d', '#ff758f', '#ffb3c1', '#ffd700'],
  });

  fire(0.2, {
    spread: 60,
    colors: ['#e0aaff', '#c77dff', '#ff85a1', '#fbcfe8'],
  });

  fire(0.35, {
    spread: 100,
    decay: 0.91,
    scalar: 1.2,
    colors: ['#ff4d6d', '#ffd166', '#f43f5e', '#ffffff'],
  });

  fire(0.1, {
    spread: 120,
    startVelocity: 25,
    decay: 0.92,
    scalar: 1.4,
    colors: ['#fb7185', '#f472b6', '#fda4af'],
  });

  fire(0.1, {
    spread: 120,
    startVelocity: 45,
    colors: ['#ffd700', '#ffe4e6', '#fca5a5'],
  });
}

export function fireGentleSparkles() {
  confetti({
    particleCount: 50,
    spread: 80,
    origin: { y: 0.6 },
    colors: ['#ffd700', '#fbcfe8', '#fed7aa', '#ffffff'],
    scalar: 0.9,
    ticks: 150,
    zIndex: 999,
  });
}
